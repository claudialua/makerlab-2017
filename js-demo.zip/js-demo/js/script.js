'use strict';

var app = document.getElementById('app');

var users = [
  {
    name: 'Ricardo',
    lastname: 'Huamani',
    age: 24
  },
  {
    name: 'Erick',
    lastname: 'Vilca',
    age: 23
  },
  {
    name: 'Ursula',
    lastname: 'Yupanqui',
    age: 28
  },
];

for (var i = 0; i < users.length; i = i + 1) {
  var userDiv = ''
    .concat('<div>')
    .concat('<p>Nombre: ' + users[i].name + '</p>')
    .concat('<p>Apellido: ' + users[i].lastname + '</p>')
    .concat('<p>Edad: ' + users[i].age + '</p>')
    .concat('</div>');

  app.innerHTML = app.innerHTML + userDiv;
}

